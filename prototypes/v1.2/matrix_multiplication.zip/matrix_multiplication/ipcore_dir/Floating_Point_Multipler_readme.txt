The following files were generated for 'Floating_Point_Multipler' in directory
C:\Users\Admin\Documents\Img Compression\matrix_multiplication\ipcore_dir\

Generate XCO file:
   CORE Generator input file containing the parameters used to generate a core.

   * Floating_Point_Multipler.xco

C Simulation Generator:
   Please see the core data sheet.

   * Floating_Point_Multipler/cmodel/floating_point_v6_1_bitacc_cmodel_lin.zip
   * Floating_Point_Multipler/cmodel/floating_point_v6_1_bitacc_cmodel_lin64.zip
   * Floating_Point_Multipler/cmodel/floating_point_v6_1_bitacc_cmodel_nt.zip
   * Floating_Point_Multipler/cmodel/floating_point_v6_1_bitacc_cmodel_nt64.zip

Generate EJava outputs:
   Please see the core data sheet.

   * demo_tb/tb_Floating_Point_Multipler.vhd

Generate Implementation Netlist:
   Binary Xilinx implementation netlist files containing the information
   required to implement the module in a Xilinx (R) FPGA.

   * Floating_Point_Multipler.ngc

Obfuscate Netlist Generator:
   Please see the core data sheet.

   * Floating_Point_Multipler.ngc

Generate Instantiation Templates:
   Template files containing code that can be used as a model for instantiating
   a CORE Generator module in an HDL design.

   * Floating_Point_Multipler.veo

Structural Simulation Model:
   Unisim VHDL or Verilog files containing the information required to simulate
   the module.

   * Floating_Point_Multipler.v

Deliver IP Symbol:
   Graphical symbol information file. Used by the ISE tools and some third party
   tools to create a symbol representing the core.

   * Floating_Point_Multipler.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * Floating_Point_Multipler.sym

Generate XMDF file:
   ISE Project Navigator interface file. ISE uses this file to determine how the
   files output by CORE Generator for the core can be integrated into your ISE
   project.

   * Floating_Point_Multipler_xmdf.tcl

Generate ISE project file:
   ISE Project Navigator support files. These are generated files and should not
   be edited directly.

   * Floating_Point_Multipler.gise
   * Floating_Point_Multipler.xise

Deliver Readme:
   Readme file for the IP.

   * Floating_Point_Multipler_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * Floating_Point_Multipler_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

